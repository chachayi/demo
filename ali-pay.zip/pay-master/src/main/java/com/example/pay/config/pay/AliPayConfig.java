package com.example.pay.config.pay;

import org.springframework.context.annotation.Configuration;

import java.io.FileWriter;
import java.io.IOException;

/**
 * @author ligen
 * @title: AliPayConfig
 * @projectName demo
 * @description:
 * @date 2019/6/1014:20
 */
@Configuration
public class AliPayConfig {

//↓↓↓↓↓↓↓↓↓↓请在这里配置您的基本信息↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓
//    netapp映射的地址，，，根据自己的需要修改
    private static String neturl = "http://121.196.103.46:8080/pay";

    // 应用ID,您的APPID，收款账号既是您的APPID对应支付宝账号 按照我文章图上的信息填写
    public static String app_id = "2016110100784516";

    // 商户私钥，您的PKCS8格式RSA2私钥  刚刚生成的私钥直接复制填写
    public static String merchant_private_key ="MIICdwIBADANBgkqhkiG9w0BAQEFAASCAmEwggJdAgEAAoGBAJvJ9LCSITuY4I3FRCjSM0dHkG2HAdViWg9vmaikqHPcKRCSri0tPSdUio3LypUVHDLvy7pGohjnqg1YOM3RWXxSuutfTyFxBXeRb/hMzX0HOffvpnTcBKAp2ttLQ5R8jaNSaaBWFyK8ka5U5gSNNdu/6SWUOCYj3GltXY4L8MjvAgMBAAECgYAmT9s6FSXRFz6Z/tpNQ6xSqjnNhbcgt+g4BZT/UUcP/yOmLLxi5c41Pug4CNcQJLnjmO88JyS0BTzfvUNy8joUIultvsMZP4zNnq1XSihv7yv2aDn52P4wbJRX8aqzXo5h7ISkMi9h22RHr0JCe4686iBgAP3m3WdZ3QJAyKdtcQJBAOLnLuqX/cJ4RY8kU+LUfanRcLBa0s6DM414gAKltCqQqfG5HwEWCZec+3qJWK9PTFSF+n4BV8p40kopYiUwBAkCQQCvxDkb/Z2o1SFvOj/9A4bsge7rCpp19QlC1bJf6HdbD9IVJx1MXsO9kNHdllmHH6e5UyfC336rwl11IX7RCVM3AkBnvsZv0vDe0vkS+sw0IW4XkECTEePjMpAGtjrpevRGpgBeGoN3jqjyHn/JRjU7aul+mAexR1HprJaR/Bv43txpAkEAlEo81Hy4k0SdnLXMXq6nGsrUw8CCaJp/Yb/hakE60b0bRXVmppQdGMYiCY1bo0D1xMl/dk4RFOA68SN9VudDKQJBALcxwaIByq18EAGm6NaRTy8E5bLq93IezcxwEiDWCI3F8dRnRpGfWbJ6blIyt08tDxd0P5rEqfj9YEQQPyfOeNE=";

    // 支付宝公钥,对应APPID下的支付宝公钥。 按照我文章图上的信息填写支付宝公钥，别填成商户公钥
    public static String alipay_public_key = "MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQDIgHnOn7LLILlKETd6BFRJ0GqgS2Y3mn1wMQmyh9zEyWlz5p1zrahRahbXAfCfSqshSNfqOmAQzSHRVjCqjsAw1jyqrXaPdKBmr90DIpIxmIyKXv4GGAkPyJ/6FTFY99uhpiq0qadD/uSzQsefWo0aTvP/65zi3eof7TcZ32oWpwIDAQAB";
    // 服务器异步通知页面路径  需http://格式的完整路径，不能加?id=123这类自定义参数，其实就是你的一个支付完成后返回的页面URL
    public static String notify_url = neturl+"/alipay/notify_url";

    // 页面跳转同步通知页面路径 需http://格式的完整路径，不能加?id=123这类自定义参数，其实就是你的一个支付完成后返回的页面URL
    public static String return_url = neturl+"/alipay/return_url";

    // 签名方式
    public static String sign_type = "RSA";

    // 字符编码格式
    public static String charset = "utf-8";

    // 支付宝网关
    public static String gatewayUrl = "https://openapi.alipaydev.com/gateway.do";

    // 支付宝网关
    public static String log_path = "C:\\";


//↑↑↑↑↑↑↑↑↑↑请在这里配置您的基本信息↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑

    /**
     * 写日志，方便测试（看网站需求，也可以改成把记录存入数据库）
     * @param sWord 要写入日志里的文本内容
     */
    public static void logResult(String sWord) {
        FileWriter writer = null;
        try {
            writer = new FileWriter(log_path + "alipay_log_" + System.currentTimeMillis()+".txt");
            writer.write(sWord);
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (writer != null) {
                try {
                    writer.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }



}
