package com.example.pay.config.pay;

import com.alibaba.fastjson.JSON;
import com.alipay.api.AlipayApiException;
import com.alipay.api.AlipayClient;
import com.alipay.api.DefaultAlipayClient;
import com.alipay.api.domain.AlipayTradePrecreateModel;
import com.alipay.api.internal.util.AlipaySignature;
import com.alipay.api.request.AlipayTradePagePayRequest;
import com.alipay.api.request.AlipayTradePrecreateRequest;
import com.alipay.api.response.AlipayTradePrecreateResponse;
import com.example.pay.domain.AlipayVo;
import com.google.zxing.BarcodeFormat;
import com.google.zxing.EncodeHintType;
import com.google.zxing.client.j2se.MatrixToImageWriter;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.qrcode.QRCodeWriter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * @author ligen
 * @title: AliPayService
 * @projectName demo
 * @description:
 * @date 2019/6/119:11
 */
@Service
public class AliPayService {
    Logger logger = LoggerFactory.getLogger("AliPayService.class");


    @Autowired
    AlipayVo staticVo;

    public static Boolean CHECK = false;

    public static String OUTTRADENO;

    //    支付服务
    public String aliPay(Integer amount) throws AlipayApiException {

        // 构建支付数据信息
        Map<String, String> data = new HashMap<>();
        data.put("subject", staticVo.getSubject()); //订单标题
        data.put("out_trade_no", new SimpleDateFormat().format(new Date())); //商户订单号,64个字符以内、可包含字母、数字、下划线；需保证在商户端不重复      //此处模拟订单号为时间
        data.put("timeout_express", staticVo.getTimout_express()); //该笔订单允许的最晚付款时间
        data.put("total_amount", amount.toString()); //订单总金额，单位为元，精确到小数点后两位，取值范围[0.01,100000000]
        data.put("product_code", "FAST_INSTANT_TRADE_PAY"); //销售产品码，商家和支付宝签约的产品码，为固定值QUICK_MSECURITY_PAY


        //构建客户端
        DefaultAlipayClient alipayRsa2Client = new DefaultAlipayClient(
                AliPayConfig.gatewayUrl,
                AliPayConfig.app_id,
                AliPayConfig.merchant_private_key,
                "json",
                AliPayConfig.charset,
                AliPayConfig.alipay_public_key,
                AliPayConfig.sign_type);
        AlipayTradePagePayRequest request = new AlipayTradePagePayRequest();  // 网页支付
//        request.setNotifyUrl(AliPayConfig.notify_url);
        request.setReturnUrl(AliPayConfig.return_url);
        request.setBizContent(JSON.toJSONString(data));
        logger.info(JSON.toJSONString(data));
        String response = alipayRsa2Client.pageExecute(request).getBody();
        logger.info(response);
        return response;
    }

    public void makeQRCode(String content, OutputStream outputStream) throws Exception{  //生成二维码
        Map<EncodeHintType,Object> map=new HashMap<>();
        map.put(EncodeHintType.CHARACTER_SET, StandardCharsets.UTF_8);
        map.put(EncodeHintType.MARGIN,2);

        QRCodeWriter qrCodeWriter=new QRCodeWriter();
        BitMatrix bitMatrix=qrCodeWriter.encode(content, BarcodeFormat.QR_CODE,300,300,map);
        MatrixToImageWriter.writeToStream(bitMatrix,"jpeg",outputStream);
    }

    public String makeCode(HttpServletResponse servletResponse) throws Exception {
        String total_amount = "2020";
        String subject = "电子合约";

        //------AlipayTradePrecreateModel------
        AlipayTradePrecreateModel model = new AlipayTradePrecreateModel();
        model.setSubject(subject);
        model.setTotalAmount(total_amount);
        model.setStoreId(UUID.randomUUID().toString());
        model.setTimeoutExpress("3m");
        model.setOutTradeNo(UUID.randomUUID().toString());

        //-----AlipayTradePagePayRequest--------
        AlipayTradePrecreateRequest request = new AlipayTradePrecreateRequest();
        request.setBizModel(model);
        request.setReturnUrl(AliPayConfig.return_url);
        request.setNotifyUrl(AliPayConfig.notify_url);

        //-----------AlipayClient---------------
        AlipayClient alipayClient = new DefaultAlipayClient(AliPayConfig.gatewayUrl,AliPayConfig.app_id,AliPayConfig.merchant_private_key, "json",AliPayConfig.charset,AliPayConfig.alipay_public_key,AliPayConfig.sign_type);

        AlipayTradePrecreateResponse response = alipayClient.execute(request);
        if (response.isSuccess()) {
            String code = response.getQrCode();
            return code;
//            makeQRCode(code,servletResponse.getOutputStream());
//            servletResponse.getOutputStream().write(bos.toByteArray());

        } else {
            throw new RuntimeException("支付宝生成二维码失败");
        }
    }

    public void notify(HttpServletRequest request, HttpServletResponse response) {
        //接收参数进行校验
        Map<String, String> parameters = new HashMap<>();
        Map<String, String[]> requestParams = request.getParameterMap();
        for (Map.Entry<String, String[]> entry : requestParams.entrySet()) {
            String key = entry.getKey();
            String[] values = entry.getValue();
            String valueStr = "";
            for (int i = 0; i < values.length; i++) {
                valueStr = (i == values.length - 1) ? valueStr + values[i] : valueStr + values[i] + ",";
            }
            parameters.put(key, valueStr);
        }
        logger.info("parameters is [parameters={}]", parameters);
        String tradeStatus =request.getParameter("trade_status");
        OUTTRADENO = request.getParameter("out_trade_no");
        if (tradeStatus.equals("TRADE_SUCCESS")){
            CHECK = true;
            logger.info("支付成功");
        }else {
            logger.info("支付失败");
        }
    }
}
