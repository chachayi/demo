package com.example.pay.controller;

import com.alipay.api.AlipayApiException;
import com.example.pay.config.pay.AliPayService;
import com.example.pay.config.pay.RtnResult;
import com.example.pay.config.pay.WXPayConfigTest;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.HashMap;
import java.util.Map;


/**
 * @author ligen
 * @title: PayController
 * @projectName demo
 * @description:
 * @date 2019/6/1013:25
 */

@Api(tags = "支付宝测试")
@RestController
public class PayController {

    Logger logger = LoggerFactory.getLogger("PayController.class");

    @Autowired
    AliPayService aliPayService;

    @ApiOperation("支付接口")
    @RequestMapping(value = "alipay/toPay/{amount}", method = RequestMethod.GET)
    public String alipay(@PathVariable(value = "amount") Integer amount) throws AlipayApiException {
        return aliPayService.aliPay(amount);
    }

    @ApiOperation("支付完成以后的回调接口")
    @GetMapping("alipay/return_url")
    public String notifyAlipay() {
        return " a li pay return ";
    }

    @ApiOperation("异步通知")
    @PostMapping("alipay/notify_url")
    public String returnAlipay(HttpServletRequest request, HttpServletResponse response) {
        aliPayService.notify(request, response);
        logger.info("----notify-----");
        return "success";
    }

    @ApiOperation("监听支付是否完成")
    @GetMapping("alipay/checkPay")
    public RtnResult checkPay() {
        Map map = new HashMap(2);
        if(AliPayService.CHECK == true){
            AliPayService.CHECK = false;
            map.put("check",1);
            map.put("tradeNo",AliPayService.OUTTRADENO);
            return RtnResult.successInfo("success", map);
        } else {
            map.put("check",2);
            return RtnResult.successInfo("fail", 2);
        }
    }

    @ApiOperation("生成二维码")
    @RequestMapping("alipay/code")
    public RtnResult code(HttpServletResponse servletResponse) throws Exception{
        String url = aliPayService.makeCode(servletResponse);
        return RtnResult.successInfo("success", url);
    }

}
